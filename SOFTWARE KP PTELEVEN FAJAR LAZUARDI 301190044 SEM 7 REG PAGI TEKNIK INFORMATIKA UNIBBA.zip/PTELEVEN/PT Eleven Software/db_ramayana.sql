-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2023 at 11:52 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ramayana`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `cetak_faktur_keluar`
-- (See below for the actual view)
--
CREATE TABLE `cetak_faktur_keluar` (
`No_Keluar` varchar(15)
,`Nama_Karyawan` varchar(30)
,`Tgl_Keluar` date
,`Nama_Barang` varchar(30)
,`Qty_Keluar` int(8)
,`satuan` varchar(10)
,`Keterangan` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `cetak_faktur_masuk`
-- (See below for the actual view)
--
CREATE TABLE `cetak_faktur_masuk` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `lap_barang_keluar`
-- (See below for the actual view)
--
CREATE TABLE `lap_barang_keluar` (
`no_keluar` varchar(15)
,`nama_karyawan` varchar(30)
,`tgl_keluar` date
,`nama_barang` varchar(30)
,`Qty_Keluar` int(8)
,`Keterangan` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `lap_barang_masuk`
-- (See below for the actual view)
--
CREATE TABLE `lap_barang_masuk` (
);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_barang`
--

CREATE TABLE `tabel_barang` (
  `Kode_Barang` varchar(10) NOT NULL,
  `Nama_Barang` varchar(30) NOT NULL,
  `Satuan` varchar(10) NOT NULL,
  `Jumlah_Stok` varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tabel_barang`
--

INSERT INTO `tabel_barang` (`Kode_Barang`, `Nama_Barang`, `Satuan`, `Jumlah_Stok`) VALUES
('B000001', 'MI', 'Psc', '9'),
('B000002', 'TAS GENDONG', 'Psc', '6');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_detail_keluar`
--

CREATE TABLE `tabel_detail_keluar` (
  `No_Keluar` varchar(15) NOT NULL,
  `Kode_Barang` varchar(15) NOT NULL,
  `Qty_Keluar` int(8) NOT NULL,
  `Keterangan` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tabel_detail_keluar`
--

INSERT INTO `tabel_detail_keluar` (`No_Keluar`, `Kode_Barang`, `Qty_Keluar`, `Keterangan`) VALUES
('K000001', 'B000001', 2, 'Menuju MiniStore'),
('K000002', 'B000002', 2, 'Berhasil');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_detail_masuk`
--

CREATE TABLE `tabel_detail_masuk` (
  `No_Masuk` varchar(15) NOT NULL,
  `Kode_Supplier` varchar(10) NOT NULL,
  `Qty_Masuk` int(8) NOT NULL,
  `Keterangan` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tabel_detail_masuk`
--

INSERT INTO `tabel_detail_masuk` (`No_Masuk`, `Kode_Supplier`, `Qty_Masuk`, `Keterangan`) VALUES
('BM00002', 'S000001', 3, 'TAS GENDONG'),
('BM00001', 'S000001', 1, 'SEPATU');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_karyawan`
--

CREATE TABLE `tabel_karyawan` (
  `Nik` varchar(15) NOT NULL,
  `Nama_Karyawan` varchar(30) NOT NULL,
  `Jabatan` varchar(20) NOT NULL,
  `Alamat` varchar(30) NOT NULL,
  `No_Handphone` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tabel_karyawan`
--

INSERT INTO `tabel_karyawan` (`Nik`, `Nama_Karyawan`, `Jabatan`, `Alamat`, `No_Handphone`) VALUES
('K000001', 'Ani', 'Petugas', 'Jl. Banjaran', '0976766'),
('K000002', 'Gusti', 'Petugas', 'Jl. Baleendah\r\n', '0975789');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_keluar`
--

CREATE TABLE `tabel_keluar` (
  `No_Keluar` varchar(15) NOT NULL,
  `Nik` varchar(15) NOT NULL,
  `Tgl_Keluar` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tabel_keluar`
--

INSERT INTO `tabel_keluar` (`No_Keluar`, `Nik`, `Tgl_Keluar`) VALUES
('K000001', 'K000001', '2023-01-24'),
('K000002', 'K000002', '2023-01-29');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_masuk`
--

CREATE TABLE `tabel_masuk` (
  `No_Masuk` varchar(15) NOT NULL,
  `Nik` varchar(15) NOT NULL,
  `Tgl_Masuk` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tabel_masuk`
--

INSERT INTO `tabel_masuk` (`No_Masuk`, `Nik`, `Tgl_Masuk`) VALUES
('BM00001', 'K000002', '2023-01-29'),
('BM00002', 'K000002', '2023-01-29');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_supplier`
--

CREATE TABLE `tabel_supplier` (
  `Kode_Supplier` varchar(10) NOT NULL,
  `Nama_Supplier` varchar(30) NOT NULL,
  `Alamat` varchar(30) NOT NULL,
  `Kota` varchar(20) NOT NULL,
  `Telpon` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tabel_supplier`
--

INSERT INTO `tabel_supplier` (`Kode_Supplier`, `Nama_Supplier`, `Alamat`, `Kota`, `Telpon`) VALUES
('S000001', 'PT ELEVEN', 'di Komplek Bojong Malaka Indah', 'Kabupaten Bandung.', '082121446840');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_user`
--

CREATE TABLE `tabel_user` (
  `Id_User` varchar(10) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tabel_user`
--

INSERT INTO `tabel_user` (`Id_User`, `Username`, `Password`) VALUES
('User01', 'admin', 'eleven'),
('User02', 'petugas', 'eleven');

-- --------------------------------------------------------

--
-- Structure for view `cetak_faktur_keluar`
--
DROP TABLE IF EXISTS `cetak_faktur_keluar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cetak_faktur_keluar`  AS SELECT `a`.`No_Keluar` AS `No_Keluar`, `b`.`Nama_Karyawan` AS `Nama_Karyawan`, `a`.`Tgl_Keluar` AS `Tgl_Keluar`, `d`.`Nama_Barang` AS `Nama_Barang`, `c`.`Qty_Keluar` AS `Qty_Keluar`, `d`.`Satuan` AS `satuan`, `c`.`Keterangan` AS `Keterangan` FROM (((`tabel_keluar` `a` join `tabel_karyawan` `b`) join `tabel_detail_keluar` `c`) join `tabel_barang` `d`) WHERE `a`.`Nik` = `b`.`Nik` AND `c`.`Kode_Barang` = `d`.`Kode_Barang` AND `a`.`No_Keluar` = `c`.`No_Keluar``No_Keluar`  ;

-- --------------------------------------------------------

--
-- Structure for view `cetak_faktur_masuk`
--
DROP TABLE IF EXISTS `cetak_faktur_masuk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cetak_faktur_masuk`  AS SELECT `a`.`No_Barang_Masuk` AS `no_barang_masuk`, `a`.`Tgl_Masuk` AS `tgl_masuk`, `b`.`Nama_Supplier` AS `nama_supplier`, `c`.`Nama_Barang` AS `nama_barang`, `d`.`Qty_Masuk` AS `Qty_Masuk` FROM (((`tabel_masuk` `a` join `tabel_supplier` `b`) join `tabel_barang` `c`) join `tabel_detail_masuk` `d`) WHERE `a`.`No_Barang_Masuk` = `d`.`No_Barang_Masuk` AND `b`.`Kode_Supplier` = `d`.`Kode_Supplier` AND `c`.`Kode_Barang` = `d`.`Kode_Barang``Kode_Barang`  ;

-- --------------------------------------------------------

--
-- Structure for view `lap_barang_keluar`
--
DROP TABLE IF EXISTS `lap_barang_keluar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lap_barang_keluar`  AS SELECT `a`.`No_Keluar` AS `no_keluar`, `b`.`Nama_Karyawan` AS `nama_karyawan`, `a`.`Tgl_Keluar` AS `tgl_keluar`, `d`.`Nama_Barang` AS `nama_barang`, `c`.`Qty_Keluar` AS `Qty_Keluar`, `c`.`Keterangan` AS `Keterangan` FROM (((`tabel_keluar` `a` join `tabel_karyawan` `b`) join `tabel_detail_keluar` `c`) join `tabel_barang` `d`) WHERE `a`.`Nik` = `b`.`Nik` AND `c`.`Kode_Barang` = `d`.`Kode_Barang` AND `a`.`No_Keluar` = `c`.`No_Keluar``No_Keluar`  ;

-- --------------------------------------------------------

--
-- Structure for view `lap_barang_masuk`
--
DROP TABLE IF EXISTS `lap_barang_masuk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lap_barang_masuk`  AS SELECT `a`.`No_Barang_Masuk` AS `No_Barang_Masuk`, `a`.`Tgl_Masuk` AS `Tgl_Masuk`, `c`.`Nama_Supplier` AS `Nama_Supplier`, `d`.`Nama_Barang` AS `nama_barang`, `b`.`Qty_Masuk` AS `Qty_Masuk` FROM (((`tabel_masuk` `a` join `tabel_detail_masuk` `b`) join `tabel_supplier` `c`) join `tabel_barang` `d`) WHERE `a`.`No_Barang_Masuk` = `b`.`No_Barang_Masuk` AND `c`.`Kode_Supplier` = `b`.`Kode_Supplier` AND `d`.`Kode_Barang` = `b`.`Kode_Barang``Kode_Barang`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_barang`
--
ALTER TABLE `tabel_barang`
  ADD PRIMARY KEY (`Kode_Barang`);

--
-- Indexes for table `tabel_detail_keluar`
--
ALTER TABLE `tabel_detail_keluar`
  ADD PRIMARY KEY (`No_Keluar`);

--
-- Indexes for table `tabel_detail_masuk`
--
ALTER TABLE `tabel_detail_masuk`
  ADD PRIMARY KEY (`No_Masuk`);

--
-- Indexes for table `tabel_karyawan`
--
ALTER TABLE `tabel_karyawan`
  ADD PRIMARY KEY (`Nik`);

--
-- Indexes for table `tabel_keluar`
--
ALTER TABLE `tabel_keluar`
  ADD PRIMARY KEY (`No_Keluar`);

--
-- Indexes for table `tabel_masuk`
--
ALTER TABLE `tabel_masuk`
  ADD PRIMARY KEY (`No_Masuk`);

--
-- Indexes for table `tabel_supplier`
--
ALTER TABLE `tabel_supplier`
  ADD PRIMARY KEY (`Kode_Supplier`);

--
-- Indexes for table `tabel_user`
--
ALTER TABLE `tabel_user`
  ADD PRIMARY KEY (`Id_User`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
